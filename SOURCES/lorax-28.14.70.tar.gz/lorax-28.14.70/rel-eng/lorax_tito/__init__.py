from lorax_tito.tagger import LoraxRHELTagger

__all__ = ['LoraxRHELTagger']
